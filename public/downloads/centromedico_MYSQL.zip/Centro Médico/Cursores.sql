DELIMITER //

CREATE PROCEDURE ObtenerFichaPacientesUltimosSeisMeses()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE paciente_id INT;
    DECLARE medico_id INT;
    DECLARE estudio_id INT;
    DECLARE paciente_nombre VARCHAR(100);
    DECLARE paciente_apellido VARCHAR(100);
    DECLARE medico_nombre VARCHAR(100);
    DECLARE medico_apellido VARCHAR(100);
    DECLARE tipo_estudio VARCHAR(100);
    DECLARE fecha_historial DATETIME;
    DECLARE resultado VARCHAR(100);

    DECLARE cur CURSOR FOR
        SELECT HE.fecha, HE.resultado, 
               HE.Paciente_idPaciente, HE.Medico_idMedico, HE.Estudio_idEstudio
        FROM HistorialEstudio HE
        WHERE HE.fecha >= DATE_SUB(NOW(), INTERVAL 6 MONTH);

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO fecha_historial, resultado, paciente_id, medico_id, estudio_id;
        IF done THEN
            LEAVE read_loop;
        END IF;

        -- Obtener los detalles del paciente
        SELECT nombre, apellido INTO paciente_nombre, paciente_apellido FROM Paciente WHERE idPaciente = paciente_id;

        -- Obtener los detalles del médico
        SELECT nombre, apellido INTO medico_nombre, medico_apellido FROM Medico WHERE idMedico = medico_id;

        -- Obtener los detalles del estudio
        SELECT tipo_estudio INTO tipo_estudio FROM Estudio WHERE idEstudio = estudio_id;

        -- Imprimir los datos en el formato requerido
        SELECT CONCAT('Datos del paciente: ', paciente_nombre, ' ', paciente_apellido) AS 'Datos del paciente';
        SELECT CONCAT('Identificación del médico: ', medico_nombre, ' ', medico_apellido) AS 'Identificación del médico';
        SELECT CONCAT('Detalle del estudio realizado: ', tipo_estudio) AS 'Detalle del estudio';
        -- Puedes adaptar la forma de salida según tus necesidades
    END LOOP;

    CLOSE cur;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE DetallePlanesPorEstudio(IN estudioID INT)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE plan_name VARCHAR(45);
    DECLARE porcentaje DECIMAL(3,2);
    DECLARE obra_social VARCHAR(45);

    DECLARE cur_planes CURSOR FOR
        SELECT p.Nombre, c.porcentaje, os.sigla
        FROM Plan p
        JOIN Cobertura c ON p.idPlan = c.plan_idPlan
        JOIN Precio pr ON p.idPlan = pr.Instituto_idInstituto
        JOIN Estudio e ON pr.Estudio_idEstudio = e.idEstudio
        LEFT JOIN AfiliacionOS aos ON e.Instituto_idInstituto = aos.ObraSocial_sigla
        LEFT JOIN ObraSocial os ON aos.ObraSocial_sigla = os.sigla
        WHERE e.idEstudio = estudioID
        ORDER BY c.porcentaje DESC;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur_planes;

    read_loop: LOOP
        FETCH cur_planes INTO plan_name, porcentaje, obra_social;

        IF done THEN
            LEAVE read_loop;
        END IF;

        SELECT CONCAT('Estudio: ', (SELECT tipo_estudio FROM Estudio WHERE idEstudio = estudioID)) AS 'Estudio';
        SELECT CONCAT('Obra social: ', obra_social) AS 'Obra social';
        SELECT CONCAT('Plan: ', plan_name, ' - Cobertura: ', porcentaje, '%') AS 'Plan y Cobertura';
    END LOOP;

    CLOSE cur_planes;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE ObtenerDatosEstudios()
BEGIN
    -- Obtener la cantidad de estudios por paciente e instituto
    SELECT 
        CONCAT(P.nombre, ' ', P.apellido) AS 'Datos del paciente',
        I.nombre AS 'Nombre del Instituto',
        COUNT(HE.idHistorialEstudio) AS 'Cantidad de estudios',
        SUM(COUNT(HE.idHistorialEstudio)) OVER(PARTITION BY P.idPaciente) AS 'Total de estudios (realizados por el paciente)',
        SUM(COUNT(HE.idHistorialEstudio)) OVER() AS 'Total de estudios realizados (todos los pacientes)'
    FROM 
        Paciente P
    JOIN 
        HistorialEstudio HE ON P.idPaciente = HE.Paciente_idPaciente
    JOIN 
        Estudio E ON HE.Estudio_idEstudio = E.idEstudio
    JOIN 
        Instituto I ON E.Instituto_idInstituto = I.idInstituto
    GROUP BY 
        P.idPaciente, I.idInstituto
    ORDER BY 
        P.idPaciente, I.idInstituto;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE ObtenerCantidadEstudiosSolicitados()
BEGIN
    SELECT 
        CONCAT(M.nombre, ' ', M.apellido) AS 'Datos del médico',
        E.tipo_estudio AS 'Nombre del estudio',
        HE.fecha AS 'Fecha del estudio',
        CONCAT(P.nombre, ' ', P.apellido) AS 'Paciente',
        COUNT(HE.idHistorialEstudio) AS 'Cantidad del estudio',
        COUNT(HE.idHistorialEstudio) OVER (PARTITION BY M.idMedico) AS 'Cantidad de estudios del médico'
    FROM 
        Medico M
    JOIN 
        HistorialEstudio HE ON M.idMedico = HE.Medico_idMedico
    JOIN 
        Estudio E ON HE.Estudio_idEstudio = E.idEstudio
    JOIN 
        Paciente P ON HE.Paciente_idPaciente = P.idPaciente
    GROUP BY 
        M.idMedico, E.idEstudio, HE.idHistorialEstudio
    ORDER BY 
        M.idMedico, E.idEstudio, HE.fecha;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE ResumenImportesObraSocial(
    IN nombre_obra_social VARCHAR(45),
    IN mes INT,
    IN anio INT
)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_numero_afiliado_os INT;
    DECLARE v_nombre_instituto VARCHAR(45);
    DECLARE v_detalle_estudio VARCHAR(45);
    DECLARE v_subtotal_instituto DECIMAL(10, 2);
    DECLARE v_total_obra_social DECIMAL(10, 2) DEFAULT 0;

    DECLARE cur CURSOR FOR
        SELECT ae.numero_afiliado_os, i.nombre AS 'Nombre del Instituto', e.tipo_estudio AS 'Detalle del estudio', p.precio AS 'Subtotal del Instituto'
        FROM AfiliacionOS ae
        JOIN Paciente pa ON ae.Paciente_idPaciente = pa.idPaciente
        JOIN HistorialEstudio he ON ae.Paciente_idPaciente = he.Paciente_idPaciente
        JOIN Estudio e ON he.Estudio_idEstudio = e.idEstudio
        JOIN Instituto i ON e.Instituto_idInstituto = i.idInstituto
        JOIN Precio p ON e.idEstudio = p.Estudio_idEstudio AND i.idInstituto = p.Instituto_idInstituto
        WHERE ae.ObraSocial_sigla = nombre_obra_social
            AND MONTH(he.fecha) = mes
            AND YEAR(he.fecha) = anio;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO v_numero_afiliado_os, v_nombre_instituto, v_detalle_estudio, v_subtotal_instituto;

        IF done THEN
            LEAVE read_loop;
        END IF;

        SET v_total_obra_social = v_total_obra_social + v_subtotal_instituto;

        SELECT v_numero_afiliado_os AS 'Numero Afiliado OS',
               v_nombre_instituto AS 'Nombre Instituto',
               v_detalle_estudio AS 'Detalle Estudio',
               v_subtotal_instituto AS 'Subtotal Instituto';

    END LOOP;

    CLOSE cur;

    SELECT CONCAT('Total de la obra social ', nombre_obra_social, ' para el mes ', mes, ' del año ', anio, ': ', v_total_obra_social) AS 'Total Obra Social';
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE EstudiosPorPlan(
    IN nombre_obra_social VARCHAR(45)
)
BEGIN
    DECLARE query TEXT;
    
    -- Creamos una tabla temporal para almacenar los resultados
    CREATE TEMPORARY TABLE IF NOT EXISTS Temp_EstudiosPorPlan (
        Estudio VARCHAR(100),
        PlanA INT DEFAULT 0,
        PlanB INT DEFAULT 0,
        PlanC INT DEFAULT 0
    );

    -- Creamos la consulta dinámica para rellenar la tabla temporal
    SET @query = CONCAT('INSERT INTO Temp_EstudiosPorPlan (Estudio, PlanA, PlanB, PlanC) SELECT e.tipo_estudio, 
            SUM(CASE WHEN pl.Nombre = ''Plan A'' THEN 1 ELSE 0 END) AS PlanA,
            SUM(CASE WHEN pl.Nombre = ''Plan B'' THEN 1 ELSE 0 END) AS PlanB,
            SUM(CASE WHEN pl.Nombre = ''Plan C'' THEN 1 ELSE 0 END) AS PlanC
        FROM AfiliacionOS aos
        JOIN Paciente p ON aos.Paciente_idPaciente = p.idPaciente
        JOIN HistorialEstudio he ON p.idPaciente = he.Paciente_idPaciente
        JOIN Estudio e ON he.Estudio_idEstudio = e.idEstudio
        JOIN Cobertura c ON he.Estudio_idEstudio = c.plan_idPlan
        JOIN Plan pl ON c.plan_idPlan = pl.idPlan
        WHERE aos.ObraSocial_sigla = ? 
        GROUP BY e.tipo_estudio');

    -- Ejecutamos la consulta dinámica
    PREPARE stmt FROM @query;
    SET @nombre_obra_social = nombre_obra_social;
    EXECUTE stmt USING @nombre_obra_social;
    DEALLOCATE PREPARE stmt;

    -- Mostramos los resultados
    SELECT * FROM Temp_EstudiosPorPlan;

    -- Eliminamos la tabla temporal
    DROP TEMPORARY TABLE IF EXISTS Temp_EstudiosPorPlan;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE EstudiosPorInstituto(
    IN fecha_desde DATE,
    IN fecha_hasta DATE
)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE tipo_estudio VARCHAR(100);
    DECLARE nombre_instituto VARCHAR(100);
    DECLARE total_estudio INT;
    DECLARE query TEXT;

    -- Creamos una tabla temporal para almacenar los resultados
    CREATE TEMPORARY TABLE IF NOT EXISTS Temp_EstudiosPorInstituto (
        Instituto VARCHAR(100),
        EstudioI INT DEFAULT 0,
        EstudioII INT DEFAULT 0,
        EstudioIII INT DEFAULT 0
    );

    -- Creamos la consulta dinámica para rellenar la tabla temporal
    SET @query = CONCAT('INSERT INTO Temp_EstudiosPorInstituto (Instituto, EstudioI, EstudioII, EstudioIII) SELECT i.nombre AS Instituto,
            SUM(CASE WHEN e.tipo_estudio = ''Estudio I'' THEN 1 ELSE 0 END) AS EstudioI,
            SUM(CASE WHEN e.tipo_estudio = ''Estudio II'' THEN 1 ELSE 0 END) AS EstudioII,
            SUM(CASE WHEN e.tipo_estudio = ''Estudio III'' THEN 1 ELSE 0 END) AS EstudioIII
        FROM HistorialEstudio he
        JOIN Estudio e ON he.Estudio_idEstudio = e.idEstudio
        JOIN Instituto i ON e.Instituto_idInstituto = i.idInstituto
        WHERE he.fecha BETWEEN ? AND ?
        GROUP BY i.nombre');

    -- Ejecutamos la consulta dinámica
    PREPARE stmt FROM @query;
    SET @fecha_desde = fecha_desde;
    SET @fecha_hasta = fecha_hasta;
    EXECUTE stmt USING @fecha_desde, @fecha_hasta;
    DEALLOCATE PREPARE stmt;

    -- Mostramos los resultados
    SELECT * FROM Temp_EstudiosPorInstituto;

    -- Eliminamos la tabla temporal
    DROP TEMPORARY TABLE IF EXISTS Temp_EstudiosPorInstituto;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE ImporteMensualPorInstituto(
    IN n_meses INT
)
BEGIN
    DECLARE i INT DEFAULT 1;
    DECLARE column_names TEXT DEFAULT '';

    DROP TEMPORARY TABLE IF EXISTS ImporteMensualInstitutoTable;

    CREATE TEMPORARY TABLE ImporteMensualInstitutoTable (
        instituto VARCHAR(45),
        total DECIMAL(10,2) DEFAULT 0
    );

    WHILE i <= n_meses DO
        SET @month_diff = n_meses - i;
        SET @query = CONCAT('
            INSERT INTO ImporteMensualInstitutoTable (instituto, total)
            SELECT 
                i.nombre AS instituto,
                COALESCE(SUM(CASE WHEN MONTH(he.fecha) = MONTH(CURDATE() - INTERVAL ', @month_diff, ' MONTH) AND YEAR(he.fecha) = YEAR(CURDATE() - INTERVAL ', @month_diff, ' MONTH) THEN he.pago_paciente END), 0) AS total
            FROM 
                HistorialEstudio he
            INNER JOIN 
                Estudio e ON he.Estudio_idEstudio = e.idEstudio
            INNER JOIN 
                Instituto i ON e.Instituto_idInstituto = i.idInstituto
            WHERE 
                (he.fecha >= DATE_FORMAT(NOW() - INTERVAL ', @month_diff, ' MONTH, "%Y-%m-01")) AND (he.fecha <= LAST_DAY(NOW()))
            GROUP BY 
                i.nombre;'
        );

        PREPARE stmt FROM @query;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;

        SET i = i + 1;
    END WHILE;

    SELECT * FROM ImporteMensualInstitutoTable;
    DROP TEMPORARY TABLE IF EXISTS ImporteMensualInstitutoTable;
END //

DELIMITER ;


SET SQL_SAFE_UPDATES = 0;
-- Actualizar 'resultado' a 'Repetir estudio'
UPDATE HistorialEstudio h
JOIN (
  SELECT idEstudio
  FROM (
    SELECT idEstudio, Instituto_idInstituto
    FROM Estudio
    ORDER BY Instituto_idInstituto
    LIMIT 1 OFFSET 1
  ) AS SegundoInstituto
) s ON h.Estudio_idEstudio = s.idEstudio
SET h.resultado = 'Repetir estudio';

-- Actualizar 'resultado' a 'Diagnóstico no confirmado'
UPDATE HistorialEstudio h
JOIN (
  SELECT idMedico
  FROM (
    SELECT idMedico
    FROM Medico
    ORDER BY idMedico
    LIMIT 1 OFFSET 2
  ) AS TercerMedico
) t ON h.Medico_idMedico = t.idMedico
SET h.resultado = 'Diagnóstico no confirmado';

SET SQL_SAFE_UPDATES = 1;

DELIMITER //

CREATE PROCEDURE IncrementarPrecios()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE especialidad_id INT;
    DECLARE precio_incrementado DECIMAL(8,2);
    
    -- Cursor para obtener cada especialidad distinta
    DECLARE cur CURSOR FOR 
        SELECT idEspecialidad
        FROM Especialidad
        ORDER BY idEspecialidad;
    
    -- Manejador para finalizar el cursor
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO especialidad_id;
        
        IF done THEN
            LEAVE read_loop;
        END IF;

        -- Calcular el incremento del precio para cada especialidad
        SET precio_incrementado = (
            SELECT precio * 1.02 
            FROM Precio 
            WHERE Estudio_idEstudio IN (
                SELECT idEstudio 
                FROM Estudio 
                WHERE Instituto_idInstituto = especialidad_id
            )
            LIMIT 1
        );

        -- Actualizar el precio para cada especialidad
        UPDATE Precio
        SET precio = precio_incrementado
        WHERE Estudio_idEstudio IN (
            SELECT idEstudio 
            FROM Estudio 
            WHERE Instituto_idInstituto = especialidad_id
        );
    END LOOP;
    CLOSE cur;
END //

DELIMITER ;







