SELECT calcular_edad('1990-05-15') AS edad;

CALL obtener_info_precio_estudio('Estudio A', @mayor, @menor, @promedio);
SELECT @mayor AS mayor_precio, @menor AS menor_precio, @promedio AS precio_promedio;

CALL obtener_listas_ordenadas();

CALL obtener_institutos_mas_utilizados('Cardiología', 3);

CALL obtener_estudios_no_realizados_ultimos_dias(7);

CALL obtener_estudios_repetidos(1, '2023-01-01', '2023-12-31');
CALL obtener_estudios_repetidos(2, '2023-01-01', '2023-06-30');

CALL obtener_repetidos_ultimos_dias(30); 

CALL ConvertirTexto('hola como estas', @resultado);
SELECT @resultado;

CALL ObtenerObrasSocialesParaEstudio('Estudio A');

CALL ObtenerCantidadEstudiosEInstitutos('OS1');
