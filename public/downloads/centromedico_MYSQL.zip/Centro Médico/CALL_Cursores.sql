CALL ObtenerFichaPacientesUltimosSeisMeses();

CALL DetallePlanesPorEstudio(1);

CALL ObtenerDatosEstudios();

CALL ObtenerCantidadEstudiosSolicitados();

CALL ResumenImportesObraSocial('OS1', 10, 2023);

CALL EstudiosPorPlan('OS1');

CALL EstudiosPorInstituto('2023-01-01', '2023-12-31');

CALL ImporteMensualPorInstituto(7);

CALL IncrementarPrecios();