CALL IngresarActualizarPrecio('NombreEstudio', 'NombreInstituto', 100.00);

CALL IngresarEstudiosProgramados(
    'Estudio B',          -- nombre del estudio
    '123456789',          -- DNI del paciente
    12345,                -- matrícula del médico
    'Instituto B',        -- nombre del instituto
    'OS2',                -- sigla de la obra social
    3,                    -- cantidad de estudios a realizarse
    7                     -- lapso en días en que los estudios deben realizarse
);

CALL IngresarAfiliado('123456789', 'OS123', 1, 56789);

CALL ProyectarEstudiosPorMes(1, 2023);

CALL ProyectarPacientesPorEdad(18, 30);

CALL ProyectarMedicosPorEspecialidad('Cardiología', NULL);

CALL ProyectarEstudiosCobertura('OS1', null);
CALL ProyectarEstudiosCobertura('OS2', 'Plan 2');

CALL ProyectarCantidadEstudios('OS1', 'Plan 1', 12345);

-- Proyectar los 7 pacientes más viejos con cualquier apellido
CALL ProyectarPacientesMasViejos(7, NULL);
-- Proyectar los 5 pacientes más viejos cuyo apellido empieza con "G"
CALL ProyectarPacientesMasViejos(5, 'G%');

CALL CalcularPrecioNeto('Instituto A', '2023-01-01', '2023-12-31');

CALL CalcularPrecioNetoObraSocial('OS1', '2023-01-01', '2023-12-31');

CALL CalcularMontoMoroso('123456789', 'Estudio A', '2023-01-15', 10.00);

CALL PrecioMinMaxObraSocial('OS1', @minPrecio, @maxPrecio);

-- Mostrar los resultados
SELECT @minPrecio AS PrecioMinimo, @maxPrecio AS PrecioMaximo;

CALL CantidadJuntasMedicas();

CALL CantidadPacientesMedicosPorPeriodo(10, 2023, @pacientes, @medicos);
SELECT @pacientes AS CantidadPacientes, @medicos AS CantidadMedicos;
