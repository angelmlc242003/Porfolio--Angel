
DELIMITER //
CREATE PROCEDURE IngresarActualizarPrecio(
    IN p_nombre_estudio VARCHAR(45),
    IN p_nombre_instituto VARCHAR(45),
    IN p_precio DECIMAL(8,2)
)
BEGIN
    DECLARE v_id_estudio INT;
    DECLARE v_id_instituto INT;
    DECLARE v_id_precio INT;

    -- Verificar si el estudio ya existe, si no, insertarlo
    INSERT INTO Estudio (tipo_estudio, precio, estado, Instituto_idInstituto)
    SELECT p_nombre_estudio, 0, 'Activo', idInstituto
    FROM Instituto
    WHERE nombre = p_nombre_instituto;

    SELECT idEstudio INTO v_id_estudio
    FROM Estudio
    WHERE tipo_estudio = p_nombre_estudio
    AND Instituto_idInstituto = (SELECT idInstituto FROM Instituto WHERE nombre = p_nombre_instituto LIMIT 1);

    -- Verificar si el instituto ya existe, si no, insertarlo
    INSERT INTO Instituto (nombre, estado)
    SELECT p_nombre_instituto, 'Activo'
    WHERE NOT EXISTS (
        SELECT 1
        FROM Instituto
        WHERE nombre = p_nombre_instituto
    );

    SELECT idInstituto INTO v_id_instituto
    FROM Instituto
    WHERE nombre = p_nombre_instituto
    LIMIT 1;

    -- Verificar si ya existe un precio para el estudio y el instituto, si no, insertarlo
    INSERT INTO Precio (precio, Instituto_idInstituto, Estudio_idEstudio)
    SELECT p_precio, v_id_instituto, v_id_estudio
    WHERE NOT EXISTS (
        SELECT 1
        FROM Precio
        WHERE Instituto_idInstituto = v_id_instituto AND Estudio_idEstudio = v_id_estudio
    );

    -- Si ya existe, actualizar el precio
    UPDATE Precio
    SET precio = p_precio
    WHERE Instituto_idInstituto = v_id_instituto AND Estudio_idEstudio = v_id_estudio;

END //
DELIMITER ;

DELIMITER //

CREATE PROCEDURE IngresarEstudiosProgramados (
    IN p_nombreEstudio VARCHAR(45),
    IN p_dniPaciente VARCHAR(15),
    IN p_matriculaMedico INT,
    IN p_nombreInstituto VARCHAR(45),
    IN p_siglaOS VARCHAR(45),
    IN p_cantidadEstudios INT,
    IN p_lapsoDias INT
)
BEGIN
    DECLARE estudio_id INT;
    DECLARE paciente_id INT;
    DECLARE medico_id INT;
    DECLARE instituto_id INT;
    DECLARE os_id INT;
    DECLARE i INT DEFAULT 1;

    -- Obtener el ID del Estudio
    SELECT idEstudio INTO estudio_id
    FROM Estudio
    WHERE tipo_estudio = p_nombreEstudio
    LIMIT 1;

    IF estudio_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No se encontró el estudio con el nombre especificado.';
    END IF;

    -- Obtener el ID del Paciente
    SELECT idPaciente INTO paciente_id
    FROM Paciente
    WHERE dni = p_dniPaciente
    LIMIT 1;

    IF paciente_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No se encontró el paciente con el DNI especificado.';
    END IF;

    -- Obtener el ID del Médico
    SELECT idMedico INTO medico_id
    FROM Medico
    WHERE matricula = p_matriculaMedico
    LIMIT 1;

    IF medico_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No se encontró el médico con la matrícula especificada.';
    END IF;

    -- Obtener el ID del Instituto
    SELECT idInstituto INTO instituto_id
    FROM Instituto
    WHERE nombre = p_nombreInstituto
    LIMIT 1;

    IF instituto_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No se encontró el instituto con el nombre especificado.';
    END IF;

    -- Obtener el ID de la Obra Social
    SELECT sigla INTO os_id
    FROM ObraSocial
    WHERE sigla = p_siglaOS
    LIMIT 1;

    IF os_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No se encontró la obra social con la sigla especificada.';
    END IF;

    -- Insertar los estudios programados en la tabla HistorialEstudio
    WHILE i <= p_cantidadEstudios DO
        -- Asegurarse de que estudio_id no sea nulo
        IF estudio_id IS NOT NULL AND paciente_id IS NOT NULL AND medico_id IS NOT NULL THEN
            INSERT INTO HistorialEstudio (
                fecha,
                Medico_idMedico,
                Estudio_idEstudio,
                Paciente_idPaciente
            )
            VALUES (
                NOW() + INTERVAL (i - 1) * p_lapsoDias DAY,
                medico_id,
                estudio_id,
                paciente_id
            );
        END IF;

        SET i = i + 1;
    END WHILE;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE IngresarAfiliado(
  IN p_dni VARCHAR(15),
  IN p_sigla_os VARCHAR(45),
  IN p_numero_plan INT,
  IN p_numero_afiliado INT
)
BEGIN
  DECLARE paciente_id INT;
  DECLARE os_id VARCHAR(45);
  DECLARE afiliado_id INT;

  -- Obtener el ID del paciente
  SELECT idPaciente INTO paciente_id FROM Paciente WHERE dni = p_dni;

  -- Verificar si la obra social existe
  SELECT sigla INTO os_id FROM ObraSocial WHERE sigla = p_sigla_os;

  -- Si no existe, insertar la obra social
  IF os_id IS NULL THEN
    INSERT INTO ObraSocial (sigla) VALUES (p_sigla_os);
  END IF;

  -- Obtener el ID de la obra social
  SELECT idAfiliacionOS INTO afiliado_id FROM AfiliacionOS WHERE Paciente_idPaciente = paciente_id AND ObraSocial_sigla = p_sigla_os;

  -- Si el afiliado ya existe, actualizar la información
  IF afiliado_id IS NOT NULL THEN
    UPDATE AfiliacionOS
    SET numero_afiliado_os = p_numero_afiliado, PlanPrepaga_numero_plan = p_numero_plan
    WHERE idAfiliacionOS = afiliado_id;
  ELSE
    -- Si no existe, insertar la nueva afiliación
    INSERT INTO AfiliacionOS (numero_afiliado_os, ObraSocial_sigla, Paciente_idPaciente)
    VALUES (p_numero_afiliado, p_sigla_os, paciente_id);
  END IF;

END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE ProyectarEstudiosPorMes(
  IN p_mes INT,
  IN p_anio INT
)
BEGIN
  SELECT
    AO.idAfiliacionOS,
    AO.numero_afiliado_os,
    AO.vencimiento_os,
    P.nombre AS nombre_paciente,
    P.apellido AS apellido_paciente,
    P.sexo,
    P.fecha_de_nacimiento,
    E.idEstudio,
    E.tipo_estudio,
    E.precio,
    HE.fecha,
    HE.resultado
  FROM AfiliacionOS AO
  JOIN Paciente P ON AO.Paciente_idPaciente = P.idPaciente
  JOIN HistorialEstudio HE ON AO.Paciente_idPaciente = HE.Paciente_idPaciente
  JOIN Estudio E ON HE.Estudio_idEstudio = E.idEstudio
  WHERE MONTH(HE.fecha) = p_mes AND YEAR(HE.fecha) = p_anio;

END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE ProyectarPacientesPorEdad(
  IN p_edad_minima INT,
  IN p_edad_maxima INT
)
BEGIN
  SELECT
    idPaciente,
    nombre,
    apellido,
    sexo,
    fecha_de_nacimiento,
    dni
  FROM Paciente
  WHERE TIMESTAMPDIFF(YEAR, fecha_de_nacimiento, CURDATE()) BETWEEN p_edad_minima AND p_edad_maxima;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE ProyectarMedicosPorEspecialidad(
  IN p_especialidad_nombre VARCHAR(45),
  IN p_sexo VARCHAR(45)
)
BEGIN
  -- Verifica si el parámetro de sexo es NULL
  IF p_sexo IS NULL THEN
    SELECT
      M.idMedico,
      M.matricula,
      M.nombre,
      M.apellido,
      M.sexo,
      M.estado
    FROM Medico M
    JOIN MedicoEspecialidad ME ON M.idMedico = ME.Medico_idMedico
    JOIN Especialidad E ON ME.Especialidad_idEspecialidad = E.idEspecialidad
    WHERE E.nombre = p_especialidad_nombre AND M.estado = 'activo';
  ELSE
    -- Si se especifica el sexo, filtra por él
    SELECT
      M.idMedico,
      M.matricula,
      M.nombre,
      M.apellido,
      M.sexo,
      M.estado
    FROM Medico M
    JOIN MedicoEspecialidad ME ON M.idMedico = ME.Medico_idMedico
    JOIN Especialidad E ON ME.Especialidad_idEspecialidad = E.idEspecialidad
    WHERE E.nombre = p_especialidad_nombre AND M.sexo = p_sexo AND M.estado = 'activo';
  END IF;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE ProyectarEstudiosCobertura(
    IN obraSocialNombre VARCHAR(45),
    IN planNombre VARCHAR(45)
)
BEGIN
    -- Variable para almacenar el plan_id correspondiente al planNombre
    DECLARE planId INT;

    -- Obtener el plan_id correspondiente al planNombre (si se proporciona)
    IF planNombre IS NOT NULL THEN
        SELECT idPlan INTO planId FROM Plan WHERE Nombre = planNombre;
    END IF;

    -- Proyectar los estudios y coberturas
    SELECT
        e.idEstudio,
        e.tipo_estudio,
        c.porcentaje AS porcentaje_cubierto
    FROM
        Estudio e
    LEFT JOIN Cobertura c ON e.Instituto_idInstituto = c.plan_idPlan
    LEFT JOIN AfiliacionOS af ON c.plan_idPlan = af.idAfiliacionOS
    WHERE
        (c.plan_idPlan = planId OR planNombre IS NULL)
        AND af.ObraSocial_sigla = obraSocialNombre;

    -- Si no se ingresa plan, listar todos los planes de la obra social
    IF planNombre IS NULL THEN
        SELECT DISTINCT p.Nombre AS Plan
        FROM Plan p
        INNER JOIN Cobertura co ON p.idPlan = co.plan_idPlan
        INNER JOIN AfiliacionOS af ON co.plan_idPlan = af.idAfiliacionOS
        WHERE af.ObraSocial_sigla = obraSocialNombre;
    END IF;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE ProyectarCantidadEstudios(
    IN nombre_ooss VARCHAR(45),
    IN nombre_plan VARCHAR(45),
    IN matricula_medico INT
)
BEGIN
    SELECT
        aos.ObraSocial_sigla AS ObraSocial,
        pp.numero_plan_prepaga AS Plan,
        m.matricula AS MatriculaMedico,
        COUNT(he.idHistorialEstudio) AS CantidadEstudios
    FROM
        AfiliacionOS aos
        JOIN Paciente p ON aos.Paciente_idPaciente = p.idPaciente
        JOIN HistorialEstudio he ON p.idPaciente = he.Paciente_idPaciente
        LEFT JOIN Medico m ON he.Medico_idMedico = m.idMedico
        LEFT JOIN AfiliacionPrepaga ap ON p.idPaciente = ap.Paciente_idPaciente
        LEFT JOIN PlanPrepaga pp ON ap.Prepaga_nombre = pp.Prepaga_nombre
    WHERE
        aos.ObraSocial_sigla = nombre_ooss
        AND (nombre_plan IS NULL OR pp.numero_plan_prepaga = nombre_plan)
        AND (matricula_medico IS NULL OR m.matricula = matricula_medico)
    GROUP BY
        aos.ObraSocial_sigla, pp.numero_plan_prepaga, m.matricula;

END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE ProyectarPacientesMasViejos(
    IN cantidad INT,
    IN patrón_apellido VARCHAR(255)
)
BEGIN
    SET patrón_apellido = IFNULL(patrón_apellido, NULL); -- Manejar el valor predeterminado NULL

    SELECT dni, fecha_de_nacimiento, nombre, apellido
    FROM Paciente
    WHERE apellido LIKE IFNULL(patrón_apellido, '%') -- Usar '%' si el patrón es nulo
    ORDER BY fecha_de_nacimiento DESC
    LIMIT cantidad;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE CalcularPrecioNeto(
    IN nombre_instituto VARCHAR(255),
    IN periodo_inicio DATE,
    IN periodo_fin DATE
)
BEGIN
    DECLARE precio_total DECIMAL(10, 2);

    SELECT SUM(p.precio * he.porcentaje_cubierto) INTO precio_total
    FROM HistorialEstudio he
    JOIN Estudio e ON he.Estudio_idEstudio = e.idEstudio
    JOIN Precio p ON e.idEstudio = p.Estudio_idEstudio
    JOIN Instituto i ON p.Instituto_idInstituto = i.idInstituto
    WHERE i.nombre = nombre_instituto
        AND he.fecha BETWEEN periodo_inicio AND periodo_fin;

    SELECT precio_total AS PrecioNeto;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE CalcularPrecioNetoObraSocial(
    IN nombre_ooss VARCHAR(45),
    IN fecha_inicio DATE,
    IN fecha_fin DATE
)
BEGIN
    DECLARE total_estudios INT;
    DECLARE total_precio DECIMAL(10, 2);

    SELECT COUNT(he.idHistorialEstudio), SUM(he.Copago_abonado)
    INTO total_estudios, total_precio
    FROM HistorialEstudio he
    JOIN AfiliacionOS aos ON he.Paciente_idPaciente = aos.Paciente_idPaciente
    JOIN ObraSocial os ON aos.ObraSocial_sigla = os.sigla
    WHERE os.sigla = nombre_ooss
        AND he.fecha BETWEEN fecha_inicio AND fecha_fin;

    SELECT total_estudios, total_precio;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE CalcularMontoMoroso(
    IN dni_paciente VARCHAR(20),
    IN tipo_estudio VARCHAR(255),
    IN fecha_realizacion DATE,
    IN punitorio_mensual DECIMAL(5, 2)
)
BEGIN
    DECLARE punitorio_diario DECIMAL(5, 2);
    DECLARE precio_estudio DECIMAL(10, 2);
    DECLARE precio_total DECIMAL(10, 2);

    -- Obtener el precio del estudio
    SELECT precio INTO precio_estudio
    FROM Estudio
    WHERE tipo_estudio = tipo_estudio
    LIMIT 1;

    -- Verificar si se encontró un precio para el estudio
    IF precio_estudio IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No se encontró un precio para el estudio proporcionado';
    END IF;

    -- Calcular punitorio diario
    SET punitorio_diario = punitorio_mensual / 30;

    -- Calcular el precio total a abonar
    SET precio_total = precio_estudio + (DATEDIFF(NOW(), fecha_realizacion) * punitorio_diario);

    SELECT precio_total;
END //

DELIMITER ;


DELIMITER //

CREATE PROCEDURE PrecioMinMaxObraSocial(
    IN obra_social_sigla VARCHAR(45),
    OUT precio_min DECIMAL(8,2),
    OUT precio_max DECIMAL(8,2)
)
BEGIN
    SELECT 
        MIN(p.precio) AS min_precio,
        MAX(p.precio) AS max_precio
    INTO
        precio_min, precio_max
    FROM
        HistorialEstudio he
        JOIN Estudio e ON he.Estudio_idEstudio = e.idEstudio
        JOIN Precio p ON e.idEstudio = p.Estudio_idEstudio
        JOIN AfiliacionOS ao ON he.Paciente_idPaciente = ao.Paciente_idPaciente
    WHERE
        ao.ObraSocial_sigla = obra_social_sigla;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE CantidadJuntasMedicas()
BEGIN
    DECLARE totalMedicos INT;
    DECLARE cantidadCombinaciones INT;

    -- Obtener la cantidad total de médicos activos
    SELECT COUNT(*) INTO totalMedicos FROM Medico WHERE estado = 'Activo';

    -- Calcular la cantidad de combinaciones posibles (de 2 a 6 médicos)
    SET cantidadCombinaciones = 0;

    IF totalMedicos >= 2 THEN
        SET cantidadCombinaciones = cantidadCombinaciones + (totalMedicos * (totalMedicos - 1)) / 2;
    END IF;

    IF totalMedicos >= 3 THEN
        SET cantidadCombinaciones = cantidadCombinaciones + (totalMedicos * (totalMedicos - 1) * (totalMedicos - 2)) / 6;
    END IF;

    IF totalMedicos >= 4 THEN
        SET cantidadCombinaciones = cantidadCombinaciones + (totalMedicos * (totalMedicos - 1) * (totalMedicos - 2) * (totalMedicos - 3)) / 24;
    END IF;

    IF totalMedicos >= 5 THEN
        SET cantidadCombinaciones = cantidadCombinaciones + (totalMedicos * (totalMedicos - 1) * (totalMedicos - 2) * (totalMedicos - 3) * (totalMedicos - 4)) / 120;
    END IF;

    IF totalMedicos >= 6 THEN
        SET cantidadCombinaciones = cantidadCombinaciones + (totalMedicos * (totalMedicos - 1) * (totalMedicos - 2) * (totalMedicos - 3) * (totalMedicos - 4) * (totalMedicos - 5)) / 720;
    END IF;

    -- Mostrar el resultado
    SELECT cantidadCombinaciones AS CantidadPosibleJuntasMedicas;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE CantidadPacientesMedicosPorPeriodo(IN mesConsulta INT, IN anioConsulta INT, OUT pacientes INT, OUT medicos INT)
BEGIN
    -- Calcular fecha de inicio y fin del mes y año especificados
    DECLARE fechaInicio DATE;
    DECLARE fechaFin DATE;
    
    SET fechaInicio = STR_TO_DATE(CONCAT(anioConsulta, '-', mesConsulta, '-01'), '%Y-%m-%d');
    SET fechaFin = LAST_DAY(fechaInicio);

    -- Contar la cantidad de pacientes que realizaron estudios en el período
    SELECT COUNT(DISTINCT Paciente_idPaciente) INTO pacientes
    FROM HistorialEstudio
    WHERE fecha BETWEEN fechaInicio AND fechaFin;

    -- Contar la cantidad de médicos solicitantes de estudios en el período
    SELECT COUNT(DISTINCT Medico_idMedico) INTO medicos
    FROM HistorialEstudio
    WHERE fecha BETWEEN fechaInicio AND fechaFin;
END //

DELIMITER ;


