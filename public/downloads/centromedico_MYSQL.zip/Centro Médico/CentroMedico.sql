-- Establecer variables de configuración
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- Eliminar el esquema si existe y crear uno nuevo
DROP SCHEMA IF EXISTS `mydb`;
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8;
USE `mydb`;

-- Crear la tabla `Instituto`
CREATE TABLE IF NOT EXISTS `Instituto` (
  `idInstituto` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(45) NULL,
  `estado` VARCHAR(45) NULL
) ENGINE=InnoDB;

-- Crear la tabla `Plan`
CREATE TABLE IF NOT EXISTS `Plan` (
  `idPlan` INT AUTO_INCREMENT PRIMARY KEY,
  `Nombre` VARCHAR(45) NULL,
  `estado` VARCHAR(45) NULL,
  `descripcion` VARCHAR(500) NULL
) ENGINE=InnoDB;

-- Crear la tabla `ObraSocial`
CREATE TABLE IF NOT EXISTS `ObraSocial` (
  `sigla` VARCHAR(45) PRIMARY KEY
) ENGINE=InnoDB;

-- Crear la tabla `Paciente`
CREATE TABLE IF NOT EXISTS `Paciente` (
  `idPaciente` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(50) NULL,
  `apellido` VARCHAR(45) NULL,
  `sexo` VARCHAR(45) NULL,
  `fecha_de_nacimiento` VARCHAR(45) NULL,
  `dni` VARCHAR(15) NULL
) ENGINE=InnoDB;

-- Crear la tabla `Cobertura`
CREATE TABLE IF NOT EXISTS `Cobertura` (
  `idCobertura` INT AUTO_INCREMENT PRIMARY KEY,
  `porcentaje` DECIMAL(3,2) NULL,
  `plan_idPlan` INT NULL,
  FOREIGN KEY (`plan_idPlan`) REFERENCES `Plan` (`idPlan`)
) ENGINE=InnoDB;

-- Crear la tabla `Estudio`
CREATE TABLE IF NOT EXISTS `Estudio` (
  `idEstudio` INT AUTO_INCREMENT PRIMARY KEY,
  `tipo_estudio` VARCHAR(45) NULL,
  `precio` DECIMAL NULL,
  `estado` VARCHAR(45) NULL,
  `Instituto_idInstituto` INT NOT NULL,
  FOREIGN KEY (`Instituto_idInstituto`) REFERENCES `Instituto` (`idInstituto`)
) ENGINE=InnoDB;

-- Crear la tabla `Medico`
CREATE TABLE IF NOT EXISTS `Medico` (
  `idMedico` INT AUTO_INCREMENT PRIMARY KEY,
  `matricula` INT NULL,
  `nombre` VARCHAR(45) NULL,
  `apellido` VARCHAR(45) NULL,
  `sexo` VARCHAR(45) NULL,
  `estado` VARCHAR(45) NULL
) ENGINE=InnoDB;

-- Crear la tabla `Especialidad`
CREATE TABLE IF NOT EXISTS `Especialidad` (
  `idEspecialidad` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre` VARCHAR(45) NULL
) ENGINE=InnoDB;

-- Crear la tabla `Prepaga`
CREATE TABLE IF NOT EXISTS `Prepaga` (
  `nombre` VARCHAR(45) PRIMARY KEY
) ENGINE=InnoDB;

-- Crear la tabla `Precio`
CREATE TABLE IF NOT EXISTS `Precio` (
  `idPrecio` INT AUTO_INCREMENT PRIMARY KEY,
  `precio` DECIMAL(8,2) NULL,
  `Instituto_idInstituto` INT NOT NULL,
  `Estudio_idEstudio` INT NOT NULL,
  FOREIGN KEY (`Instituto_idInstituto`) REFERENCES `Instituto` (`idInstituto`),
  FOREIGN KEY (`Estudio_idEstudio`) REFERENCES `Estudio` (`idEstudio`)
) ENGINE=InnoDB;

-- Crear la tabla `AfiliacionOS`
CREATE TABLE IF NOT EXISTS `AfiliacionOS` (
  `idAfiliacionOS` INT AUTO_INCREMENT PRIMARY KEY,
  `numero_afiliado_os` INT NULL,
  `vencimiento_os` DATETIME NULL,
  `ObraSocial_sigla` VARCHAR(45) NOT NULL,
  `Paciente_idPaciente` INT NOT NULL,
  FOREIGN KEY (`ObraSocial_sigla`) REFERENCES `ObraSocial` (`sigla`),
  FOREIGN KEY (`Paciente_idPaciente`) REFERENCES `Paciente` (`idPaciente`)
) ENGINE=InnoDB;

-- Crear la tabla `AfiliacionPrepaga`
CREATE TABLE IF NOT EXISTS `AfiliacionPrepaga` (
  `idAfiliacionPrepaga` INT AUTO_INCREMENT PRIMARY KEY,
  `numero_afiliado_prepago` VARCHAR(45) NULL,
  `vencimiento_prepago` DATETIME NULL,
  `Prepaga_nombre` VARCHAR(45) NOT NULL,
  `Paciente_idPaciente` INT NOT NULL,
  FOREIGN KEY (`Prepaga_nombre`) REFERENCES `Prepaga` (`nombre`),
  FOREIGN KEY (`Paciente_idPaciente`) REFERENCES `Paciente` (`idPaciente`)
) ENGINE=InnoDB;

-- Crear la tabla `PlanPrepaga`
CREATE TABLE IF NOT EXISTS `PlanPrepaga` (
  `idPlanPrepaga` INT AUTO_INCREMENT PRIMARY KEY,
  `numero_plan_prepaga` INT NULL,
  `porcentaje_cobertura` DECIMAL(5,2) NULL,
  `Prepaga_nombre` VARCHAR(45) NOT NULL,
  FOREIGN KEY (`Prepaga_nombre`) REFERENCES `Prepaga` (`nombre`)
) ENGINE=InnoDB;

-- Crear la tabla `HistorialEstudio`
CREATE TABLE IF NOT EXISTS `HistorialEstudio` (
  `idHistorialEstudio` INT AUTO_INCREMENT PRIMARY KEY,
  `fecha` DATETIME NULL,
  `porcentaje_cubierto` VARCHAR(45) NULL,
  `pago_paciente` VARCHAR(45) NULL,
  `resultado` VARCHAR(45) NULL,
  `Copago_abonado` VARCHAR(45) NULL,
  `Medico_idMedico` INT NOT NULL,
  `Estudio_idEstudio` INT NOT NULL,
  `Paciente_idPaciente` INT NOT NULL,
  FOREIGN KEY (`Medico_idMedico`) REFERENCES `Medico` (`idMedico`),
  FOREIGN KEY (`Estudio_idEstudio`) REFERENCES `Estudio` (`idEstudio`),
  FOREIGN KEY (`Paciente_idPaciente`) REFERENCES `Paciente` (`idPaciente`)
) ENGINE=InnoDB;

-- Crear la tabla `MedicoEspecialidad`
CREATE TABLE IF NOT EXISTS `MedicoEspecialidad` (
  `idMedicoEspecialidad` INT AUTO_INCREMENT PRIMARY KEY,
  `Medico_idMedico` INT NOT NULL,
  `Especialidad_idEspecialidad` INT NULL,
  FOREIGN KEY (`Medico_idMedico`) REFERENCES `Medico` (`idMedico`),
  FOREIGN KEY (`Especialidad_idEspecialidad`) REFERENCES `Especialidad` (`idEspecialidad`)
) ENGINE=InnoDB;

-- Restaurar la configuración original
SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
