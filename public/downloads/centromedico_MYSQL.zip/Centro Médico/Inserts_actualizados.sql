-- Institutos
INSERT INTO Instituto (nombre, estado) VALUES
('Instituto A', 'Activo'),
('Instituto B', 'Inactivo'),
('Instituto C', 'Activo'),
('Instituto D', 'Inactivo'),
('Instituto E', 'Activo'),
('Instituto F', 'Inactivo'),
('Instituto G', 'Activo'),
('Instituto H', 'Inactivo'),
('Instituto I', 'Activo'),
('Instituto J', 'Inactivo');

-- Planes
INSERT INTO Plan (Nombre, estado, descripcion) VALUES
('Plan 1', 'Activo', 'Descripción del Plan 1'),
('Plan 2', 'Inactivo', 'Descripción del Plan 2'),
('Plan 3', 'Activo', 'Descripción del Plan 3'),
('Plan 4', 'Inactivo', 'Descripción del Plan 4'),
('Plan 5', 'Activo', 'Descripción del Plan 5'),
('Plan 6', 'Inactivo', 'Descripción del Plan 6'),
('Plan 7', 'Activo', 'Descripción del Plan 7'),
('Plan 8', 'Inactivo', 'Descripción del Plan 8'),
('Plan 9', 'Activo', 'Descripción del Plan 9'),
('Plan 10', 'Inactivo', 'Descripción del Plan 10');

-- Obras Sociales
INSERT INTO ObraSocial (sigla) VALUES
('OS1'),
('OS2'),
('OS3'),
('OS4'),
('OS5'),
('OS6'),
('OS7'),
('OS8'),
('OS9'),
('OS10');

-- Pacientes
INSERT INTO Paciente (nombre, apellido, sexo, fecha_de_nacimiento, dni) VALUES
('Juan', 'Perez', 'Masculino', '1990-05-15', '123456789'),
('Ana', 'Gomez', 'Femenino', '1985-08-22', '987654321'),
('Carlos', 'Lopez', 'Masculino', '1972-02-10', '567890123'),
('Laura', 'Rodriguez', 'Femenino', '1998-11-30', '345678901'),
('Pedro', 'Martinez', 'Masculino', '1980-07-05', '789012345'),
('Sofia', 'Sanchez', 'Femenino', '1995-04-18', '234567890'),
('Luis', 'Garcia', 'Masculino', '1987-09-25', '901234567'),
('Maria', 'Lopez', 'Femenino', '1975-06-12', '456789012'),
('Elena', 'Gomez', 'Femenino', '1993-03-08', '234567890'),
('Hugo', 'Fernandez', 'Masculino', '1983-01-04', '567890123');

-- Coberturas
INSERT INTO Cobertura (porcentaje, plan_idPlan) VALUES
(0.8, 1),
(0.7, 2),
(0.9, 3),
(0.6, 4),
(0.85, 5),
(0.75, 6),
(0.92, 7),
(0.68, 8),
(0.88, 9),
(0.78, 10);

-- Estudios
INSERT INTO Estudio (tipo_estudio, precio, estado, Instituto_idInstituto) VALUES
('Estudio A', 150.00, 'Activo', 1),
('Estudio B', 200.00, 'Inactivo', 2),
('Estudio C', 180.00, 'Activo', 3),
('Estudio D', 220.00, 'Inactivo', 4),
('Estudio E', 160.00, 'Activo', 5),
('Estudio F', 240.00, 'Inactivo', 6),
('Estudio G', 190.00, 'Activo', 7),
('Estudio H', 210.00, 'Inactivo', 8),
('Estudio I', 170.00, 'Activo', 9),
('Estudio J', 230.00, 'Inactivo', 10);

-- Médicos
INSERT INTO Medico (matricula, nombre, apellido, sexo, estado) VALUES
(12345, 'Dr. González', 'Pérez', 'Masculino', 'Activo'),
(67890, 'Dra. Ramírez', 'Gómez', 'Femenino', 'Activo'),
(54321, 'Dr. Rodríguez', 'López', 'Masculino', 'Inactivo'),
(98765, 'Dra. Martínez', 'Martínez', 'Femenino', 'Inactivo'),
(24680, 'Dr. Sánchez', 'Rodríguez', 'Masculino', 'Inactivo'),
(13579, 'Dr. García', 'Sánchez', 'Masculino', 'Inactivo'),
(24680, 'Dra. López', 'Martínez', 'Femenino', 'Inactivo'),
(35791, 'Dr. Pérez', 'Gómez', 'Masculino', 'Inactivo'),
(46802, 'Dra. Rodríguez', 'Pérez', 'Femenino', 'Inactivo'),
(57913, 'Dr. Martínez', 'Gómez', 'Masculino', 'Inactivo');

-- Especialidades
INSERT INTO Especialidad (nombre) VALUES
('Cardiología'),
('Dermatología'),
('Gastroenterología'),
('Neurología'),
('Oftalmología'),
('Oncología'),
('Pediatría'),
('Psiquiatría'),
('Traumatología'),
('Urología');

-- Médicos con varias especialidades (activos)
INSERT INTO MedicoEspecialidad (Medico_idMedico, Especialidad_idEspecialidad) VALUES
(1, 1), -- Dr. González con Cardiología
(1, 2), -- Dr. González también con Dermatología
(7, 3), -- Dra. López con Gastroenterología
(7, 4); -- Dra. López también con Neurología

-- Médicos sin especialidad
INSERT INTO MedicoEspecialidad (Medico_idMedico, Especialidad_idEspecialidad) VALUES
(3, NULL), -- Dr. Rodríguez sin especialidad
(5, NULL); -- Dr. Sánchez sin especialidad

-- Prepagas
INSERT INTO Prepaga (nombre) VALUES
('Prepaga 1'),
('Prepaga 2'),
('Prepaga 3'),
('Prepaga 4'),
('Prepaga 5'),
('Prepaga 6'),
('Prepaga 7'),
('Prepaga 8'),
('Prepaga 9'),
('Prepaga 10');

-- Precios
INSERT INTO Precio (precio, Instituto_idInstituto, Estudio_idEstudio) VALUES
(180.00, 1, 1),
(210.00, 2, 2),
(160.00, 3, 3),
(200.00, 4, 4),
(190.00, 5, 5),
(220.00, 6, 6),
(170.00, 7, 7),
(230.00, 8, 8),
(200.00, 9, 9),
(210.00, 10, 10);

-- HistorialEstudio
INSERT INTO HistorialEstudio (fecha, porcentaje_cubierto, pago_paciente, resultado, Copago_abonado, Medico_idMedico, Estudio_idEstudio, Paciente_idPaciente)
VALUES
('2023-01-15 08:30:00', '80%', '50.00', 'Normal', '20.00', 1, 1, 1),
('2023-02-20 10:45:00', '90%', '30.00', 'Anormal', '15.00', 2, 2, 2),
('2023-03-10 14:15:00', '85%', '40.00', 'Normal', '25.00', 3, 3, 3),
('2023-04-05 11:00:00', '75%', '60.00', 'Anormal', '30.00', 4, 4, 4),
('2023-05-12 09:30:00', '92%', '20.00', 'Normal', '10.00', 5, 5, 5),
('2023-06-18 13:45:00', '88%', '35.00', 'Anormal', '18.00', 1, 6, 6),
('2023-07-22 16:20:00', '82%', '45.00', 'Normal', '22.00', 2, 7, 7),
('2023-08-30 08:00:00', '78%', '55.00', 'Anormal', '28.00', 3, 8, 8),
('2023-09-10 10:10:00', '91%', '25.00', 'Normal', '12.00', 4, 9, 9),
('2023-10-05 12:55:00', '86%', '38.00', 'Anormal', '20.00', 5, 10, 10);


-- Afiliaciones con cobertura (obra social)
INSERT INTO AfiliacionOS (numero_afiliado_os, vencimiento_os, ObraSocial_sigla, Paciente_idPaciente) VALUES
(123456, '2024-12-31', 'OS1', 1); -- Juan Pérez con Obra Social OS1

INSERT INTO AfiliacionOS (numero_afiliado_os, vencimiento_os, ObraSocial_sigla, Paciente_idPaciente) VALUES
(987654, '2023-10-15', 'OS2', 2); -- Ana Gómez con Obra Social OS2

INSERT INTO AfiliacionOS (numero_afiliado_os, vencimiento_os, ObraSocial_sigla, Paciente_idPaciente) VALUES
(345678, '2025-05-20', 'OS3', 3); -- Carlos Lopez con Obra Social OS3

-- Afiliaciones con cobertura (prepaga)
INSERT INTO AfiliacionPrepaga (numero_afiliado_prepago, vencimiento_prepago, Prepaga_nombre, Paciente_idPaciente) VALUES
('P12345', '2023-08-31', 'Prepaga 1', 4); -- Laura Rodriguez con Prepaga 1

INSERT INTO AfiliacionPrepaga (numero_afiliado_prepago, vencimiento_prepago, Prepaga_nombre, Paciente_idPaciente) VALUES
('P98765', '2024-11-15', 'Prepaga 2', 5); -- Pedro Martinez con Prepaga 2

INSERT INTO AfiliacionPrepaga (numero_afiliado_prepago, vencimiento_prepago, Prepaga_nombre, Paciente_idPaciente) VALUES
('P54321', '2022-06-20', 'Prepaga 3', 6); -- Sofia Sanchez con Prepaga 3

-- Afiliados con múltiples coberturas
INSERT INTO AfiliacionOS (numero_afiliado_os, vencimiento_os, ObraSocial_sigla, Paciente_idPaciente) VALUES
(111111, '2024-12-31', 'OS4', 7); -- Luis Garcia con Obra Social OS4

INSERT INTO AfiliacionOS (numero_afiliado_os, vencimiento_os, ObraSocial_sigla, Paciente_idPaciente) VALUES
(222222, '2023-10-15', 'OS5', 8); -- Maria Lopez con Obra Social OS5

INSERT INTO AfiliacionPrepaga (numero_afiliado_prepago, vencimiento_prepago, Prepaga_nombre, Paciente_idPaciente) VALUES
('P99999', '2023-08-31', 'Prepaga 4', 7); -- Luis Garcia con Prepaga 4

INSERT INTO AfiliacionPrepaga (numero_afiliado_prepago, vencimiento_prepago, Prepaga_nombre, Paciente_idPaciente) VALUES
('P88888', '2024-11-15', 'Prepaga 5', 8); -- Maria Lopez con Prepaga 5

-- Insertar datos en la tabla Estudio
INSERT INTO Estudio (tipo_estudio, precio, estado, Instituto_idInstituto)
VALUES ('Estudio1', 100.00, 'Activo', 1);

-- Insertar datos en la tabla Cobertura sin establecer relación con ningún plan
INSERT INTO Cobertura (porcentaje, plan_idPlan)
VALUES (0.00, NULL);

-- Insertar más datos en la tabla Estudio
INSERT INTO Estudio (tipo_estudio, precio, estado, Instituto_idInstituto)
VALUES ('Estudio2', 150.00, 'Activo', 1);

-- Insertar más datos en la tabla Cobertura sin establecer relación con ningún plan
INSERT INTO Cobertura (porcentaje, plan_idPlan)
VALUES (0.00, NULL);

INSERT INTO Plan (Nombre, estado, descripcion) VALUES
('Plan Sin Cobertura', 'Activo', 'Descripción del Plan Sin Cobertura');

-- Precios para las Obras Sociales
INSERT INTO Precio (precio, Instituto_idInstituto, Estudio_idEstudio) VALUES
(150.00, 1, 1), -- Para OS1
(200.00, 2, 2), -- Para OS2
(180.00, 3, 3) -- Para OS3

