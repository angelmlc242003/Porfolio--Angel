DELIMITER //

CREATE FUNCTION calcular_edad(fecha_nacimiento DATE)
RETURNS INT
BEGIN
    DECLARE edad INT;

    -- Calcular la edad restando el año actual menos el año de nacimiento
    SET edad = YEAR(CURDATE()) - YEAR(fecha_nacimiento);

    -- Ajustar la edad si aún no ha pasado el cumpleaños en el año actual
    IF MONTH(CURDATE()) < MONTH(fecha_nacimiento) OR 
       (MONTH(CURDATE()) = MONTH(fecha_nacimiento) AND DAY(CURDATE()) < DAY(fecha_nacimiento)) THEN
        SET edad = edad - 1;
    END IF;

    RETURN edad;
END//

DELIMITER ;

DELIMITER //

CREATE PROCEDURE obtener_info_precio_estudio(IN nombre_estudio VARCHAR(100), OUT mayor DECIMAL(8,2), OUT menor DECIMAL(8,2), OUT promedio DECIMAL(8,2))
BEGIN
    SELECT MAX(Precio.precio), MIN(Precio.precio), AVG(Precio.precio)
    INTO mayor, menor, promedio
    FROM Precio
    INNER JOIN Estudio ON Precio.Estudio_idEstudio = Estudio.idEstudio
    WHERE Estudio.tipo_estudio = nombre_estudio;
END//

DELIMITER ;

DELIMITER //

CREATE PROCEDURE obtener_listas_ordenadas()
BEGIN
    DROP TEMPORARY TABLE IF EXISTS temp_listas;

    CREATE TEMPORARY TABLE temp_listas (
        id INT AUTO_INCREMENT PRIMARY KEY,
        tipo VARCHAR(20),
        nombre VARCHAR(45),
        precio DECIMAL(8,2),
        estado VARCHAR(45)
    );

    INSERT INTO temp_listas (tipo, nombre, precio, estado)
        SELECT 'Obra Social', sigla, NULL, NULL
        FROM ObraSocial
        UNION ALL
        SELECT 'Especialidad', nombre, NULL, NULL
        FROM Especialidad
        UNION ALL
        SELECT 'Instituto', nombre, NULL, estado
        FROM Instituto
        UNION ALL
        SELECT 'Estudio', tipo_estudio, precio, estado
        FROM Estudio;

    SELECT *
    FROM temp_listas
    ORDER BY tipo, nombre;

    DROP TEMPORARY TABLE IF EXISTS temp_listas;
END//

DELIMITER ;

DELIMITER //

CREATE PROCEDURE obtener_institutos_mas_utilizados(IN nombre_especialidad VARCHAR(45), IN cantidad_deseada INT)
BEGIN
    -- Creamos una tabla temporal para almacenar los resultados
    CREATE TEMPORARY TABLE IF NOT EXISTS temp_institutos_utilizados (
        nombre_instituto VARCHAR(45),
        cantidad_utilizada INT
    );

    -- Insertamos los datos requeridos en la tabla temporal
    INSERT INTO temp_institutos_utilizados (nombre_instituto, cantidad_utilizada)
    SELECT i.nombre, COUNT(*) AS cantidad_utilizada
    FROM Instituto i
    JOIN Estudio e ON i.idInstituto = e.Instituto_idInstituto
    JOIN MedicoEspecialidad me ON e.idEstudio = me.Especialidad_idEspecialidad
    JOIN Especialidad es ON me.Especialidad_idEspecialidad = es.idEspecialidad
    WHERE es.nombre = nombre_especialidad
    GROUP BY i.nombre
    ORDER BY cantidad_utilizada DESC
    LIMIT cantidad_deseada;

    -- Seleccionamos los resultados
    SELECT * FROM temp_institutos_utilizados;

    -- Eliminamos la tabla temporal al finalizar
    DROP TEMPORARY TABLE IF EXISTS temp_institutos_utilizados;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE obtener_estudios_no_realizados_ultimos_dias(IN n INT)
BEGIN
    SELECT e.*
    FROM Estudio e
    LEFT JOIN HistorialEstudio he ON e.idEstudio = he.Estudio_idEstudio
    WHERE he.fecha IS NULL OR DATEDIFF(NOW(), he.fecha) > n;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE obtener_estudios_repetidos(
    IN cantidad_minima INT,
    IN fecha_desde DATE,
    IN fecha_hasta DATE
)
BEGIN
    -- Creamos la tabla temporal
    CREATE TEMPORARY TABLE TempTabla (
        paciente_id INT,
        paciente_nombre VARCHAR(50),
        estudio VARCHAR(50),
        cantidad INT
    );

    -- Insertamos datos en la tabla temporal
    INSERT INTO TempTabla
    SELECT he.Paciente_idPaciente AS paciente_id,
           p.nombre AS paciente_nombre,
           e.tipo_estudio AS estudio,
           COUNT(*) AS cantidad
    FROM HistorialEstudio he
    INNER JOIN Estudio e ON he.Estudio_idEstudio = e.idEstudio
    INNER JOIN Paciente p ON he.Paciente_idPaciente = p.idPaciente
    WHERE he.fecha BETWEEN fecha_desde AND fecha_hasta
    GROUP BY paciente_id, estudio
    HAVING COUNT(*) >= cantidad_minima;

    -- Verificamos si hay resultados en la tabla temporal y los mostramos
    IF (SELECT COUNT(*) FROM TempTabla) > 0 THEN
        SELECT * FROM TempTabla;
    ELSE
        SELECT 'No se encontraron estudios que cumplan con los criterios.';
    END IF;

    -- Eliminamos la tabla temporal
    DROP TEMPORARY TABLE IF EXISTS TempTabla;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE obtener_repetidos_ultimos_dias(IN dias INT)
BEGIN
    SELECT he.Estudio_idEstudio AS estudio_repetido,
           e.tipo_estudio AS nombre_estudio,
           he.fecha AS fecha_realizacion,
           he.Paciente_idPaciente AS id_paciente,
           he.Medico_idMedico AS id_medico
    FROM HistorialEstudio he
    INNER JOIN Estudio e ON he.Estudio_idEstudio = e.idEstudio
    WHERE he.fecha >= DATE_SUB(CURDATE(), INTERVAL dias DAY)
    AND EXISTS (
        SELECT 1
        FROM HistorialEstudio sub
        WHERE sub.Paciente_idPaciente = he.Paciente_idPaciente
        AND sub.Estudio_idEstudio = he.Estudio_idEstudio
        AND sub.Medico_idMedico = he.Medico_idMedico
        AND sub.fecha < he.fecha
        AND sub.fecha >= DATE_SUB(he.fecha, INTERVAL dias DAY)
    );
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE ConvertirTexto(IN texto VARCHAR(255), OUT resultado VARCHAR(255))
BEGIN
    DECLARE texto_convertido VARCHAR(255);
    DECLARE i INT DEFAULT 1;

    SET texto_convertido = LOWER(texto);
    SET resultado = UPPER(SUBSTRING(texto_convertido,1,1));

    WHILE(i < LENGTH(texto_convertido)) DO
        IF (SUBSTRING(texto_convertido, i, 1) = ' ') THEN
            SET resultado = CONCAT(resultado, ' ', UPPER(SUBSTRING(texto_convertido, i+1, 1)));
            SET i = i + 1;
        ELSE
            SET resultado = CONCAT(resultado, SUBSTRING(texto_convertido, i+1, 1));
        END IF;
        SET i = i + 1;
    END WHILE;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE ObtenerObrasSocialesParaEstudio(IN estudio_nombre VARCHAR(100))
BEGIN
    SELECT DISTINCT OS.sigla AS ObraSocial, 'Categoría Desconocida' AS Categoria
    FROM ObraSocial OS
    INNER JOIN AfiliacionOS AOS ON OS.sigla = AOS.ObraSocial_sigla
    INNER JOIN Paciente P ON AOS.Paciente_idPaciente = P.idPaciente
    INNER JOIN HistorialEstudio HE ON P.idPaciente = HE.Paciente_idPaciente
    INNER JOIN Estudio E ON HE.Estudio_idEstudio = E.idEstudio
    WHERE E.tipo_estudio = estudio_nombre;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE ObtenerCantidadEstudiosEInstitutos(
    IN sigla_obra_social VARCHAR(45)
)
BEGIN
    SELECT 
        OS.sigla AS ObraSocial,
        E.tipo_estudio AS Estudio,
        COUNT(DISTINCT E.idEstudio) AS CantidadEstudio,
        COUNT(DISTINCT E.Instituto_idInstituto) AS CantidadInstituto
    FROM ObraSocial OS
    INNER JOIN AfiliacionOS AOS ON OS.sigla = AOS.ObraSocial_sigla
    INNER JOIN Paciente P ON AOS.Paciente_idPaciente = P.idPaciente
    INNER JOIN HistorialEstudio HE ON P.idPaciente = HE.Paciente_idPaciente
    INNER JOIN Estudio E ON HE.Estudio_idEstudio = E.idEstudio
    WHERE OS.sigla = sigla_obra_social
    GROUP BY OS.sigla, E.tipo_estudio;
END //

DELIMITER ;


